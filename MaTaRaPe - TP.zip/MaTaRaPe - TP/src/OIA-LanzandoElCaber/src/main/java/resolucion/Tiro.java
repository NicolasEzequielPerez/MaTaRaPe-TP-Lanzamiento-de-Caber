package resolucion;

public class Tiro {

	private double distancia;
	private double angulo;

	public Tiro(final double distancia, final double angulo) {
		this.distancia = distancia;
		this.angulo = angulo;
	}

	public boolean validarTiro() {
		return (Math.abs(angulo) < 90.00);
	}

	public double determinarDistancia() {
		return (Math.abs(angulo) > 90.00 / 4) ? distancia * 0.8 : distancia;
	}

	public double getAngulo() {
		return Math.abs(angulo);
	}
}
