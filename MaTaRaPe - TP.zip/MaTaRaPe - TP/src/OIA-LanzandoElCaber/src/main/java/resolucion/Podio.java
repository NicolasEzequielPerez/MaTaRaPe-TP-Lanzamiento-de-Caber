package resolucion;

import java.util.PriorityQueue;

public class Podio {

	private Concursante[] concursantes;
	private PriorityQueue<Consistencia> constanciaGanadores;
	private PriorityQueue<Concursante> distanciaGanadores;

	public Podio(Concursante[] concursantes) {
		this.concursantes = concursantes;
		this.constanciaGanadores = new PriorityQueue<>();
		this.distanciaGanadores = new PriorityQueue<>();
	}

	public void resolver() {
		for (int i = 0; i < concursantes.length; i++) {
			if (!concursantes[i].isDescalificado()) {
				constanciaGanadores.add(concursantes[i].calcularConsistencia());
			}

			if (concursantes[i].getDistanciaTotal() > 0.00) {
				distanciaGanadores.add(concursantes[i]);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();

		if (!constanciaGanadores.isEmpty()) {
			str.append(constanciaGanadores.poll());
			while (!constanciaGanadores.isEmpty()) {
				str.append(" " + constanciaGanadores.poll());
			}
		} else {
			str.append(0);
		}

		if (!distanciaGanadores.isEmpty()) {
			str.append("\n" + distanciaGanadores.poll());
			while (!distanciaGanadores.isEmpty()) {
				str.append(" " + distanciaGanadores.poll());
			}
		} else {
			str.append("\n" + 0);
		}

		return str.toString();
	}

}