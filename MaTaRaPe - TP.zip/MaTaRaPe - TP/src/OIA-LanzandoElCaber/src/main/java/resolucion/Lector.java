package resolucion;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.Scanner;

public class Lector {

	private Lector() {
	}

	public static Podio leer(String path) {
		Podio podio = null;
		File file = new File(path);
		Scanner scanner = null;

		try {
			scanner = new Scanner(file);
			scanner.useLocale(Locale.ENGLISH);

			int n = scanner.nextInt();
			Concursante[] concursantes = new Concursante[n];

			for (int i = 0; i < n; i++) {
				Tiro[] tiros = new Tiro[3];
				for (int j = 0; j < tiros.length; j++) {
					tiros[j] = new Tiro(scanner.nextDouble(), scanner.nextDouble());
				}
				concursantes[i] = new Concursante(tiros, i + 1);
			}

			podio = new Podio(concursantes);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}

		return podio;
	}

}
